from .nurbslib import *

__doc__ = nurbslib.__doc__
if hasattr(nurbslib, "__all__"):
    __all__ = nurbslib.__all__